"use client";

import { useCallback, useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Step = { id: string; title: string; estimated_minutes: number | null };
type Task = {
  id: string; title: string; priority: string; status: string; category: string;
  start_time: string | null; estimated_minutes: number | null; ai_reason: string | null;
  task_steps: Step[];
};

const PRIORITY_LABEL: Record<string, { text: string; cls: string }> = {
  urgent: { text: "عاجل", cls: "bg-red-50 text-red-700" },
  high: { text: "مهم", cls: "bg-orange-50 text-orange-700" },
  normal: { text: "عادي", cls: "bg-blue-50 text-blue-700" },
  low: { text: "مؤجَّل", cls: "bg-slate-100 text-slate-600" }
};

function localDate() {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export default function TodayPage() {
  const supabase = createClient();
  const [text, setText] = useState("");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [booting, setBooting] = useState(true);
  const [error, setError] = useState("");
  const [open, setOpen] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data: plan } = await supabase.from("daily_plans")
      .select("id, ai_summary, morning_input").eq("plan_date", localDate()).maybeSingle();
    if (!plan) { setTasks([]); setSummary(""); setBooting(false); return; }
    setSummary(plan.ai_summary ?? "");
    setText((t) => t || plan.morning_input || "");
    const { data } = await supabase.from("tasks")
      .select("id, title, priority, status, category, start_time, estimated_minutes, ai_reason, task_steps(id, title, estimated_minutes)")
      .eq("plan_id", plan.id).order("start_time", { ascending: true });
    setTasks((data as Task[] | null) ?? []);
    setBooting(false);
  }, [supabase]);

  useEffect(() => { load(); }, [load]);

  async function createPlan() {
    if (!text.trim()) { setError("اكتب ما تريد إنجازه أولًا."); return; }
    if (tasks.length > 0 && !confirm("سيتم استبدال خطة اليوم الحالية. هل تريد المتابعة؟")) return;
    setLoading(true); setError("");
    const now = new Date();
    const res = await fetch("/api/plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text, date: localDate(),
        nowTime: now.toTimeString().slice(0, 5),
        tzOffsetMinutes: now.getTimezoneOffset()
      })
    });
    const data = await res.json().catch(() => ({}));
    setLoading(false);
    if (!res.ok) { setError(data.error ?? "حدث خطأ غير متوقع."); return; }
    await load();
  }

  async function toggle(t: Task) {
    const next = t.status === "done" ? "todo" : "done";
    setTasks((prev) => prev.map((x) => (x.id === t.id ? { ...x, status: next } : x)));
    const { error } = await supabase.from("tasks").update({ status: next }).eq("id", t.id);
    if (error) { setError("تعذّر حفظ التغيير."); load(); }
  }

  const done = tasks.filter((t) => t.status === "done").length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  const fmt = (iso: string | null) =>
    iso ? new Date(iso).toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }) : "";

  return (
    <main className="mx-auto max-w-3xl p-4">
      <h1 className="text-2xl font-bold text-brand-700">خطة اليوم</h1>

      <div className="mt-4 rounded-3xl bg-white p-4 shadow-sm">
        <textarea value={text} onChange={(e) => setText(e.target.value)}
          placeholder="اكتب كل ما تريده اليوم: مهام، مواعيد، أفكار… بأي ترتيب"
          className="min-h-36 w-full rounded-xl border border-slate-300 p-4" />
        <button onClick={createPlan} disabled={loading}
          className="mt-3 w-full rounded-xl bg-brand-500 py-3 font-semibold text-white hover:bg-brand-600 disabled:opacity-60">
          {loading ? "أحلل طلبك وأجهز خطة التنفيذ…" : tasks.length ? "✨ أعد إنشاء الخطة" : "✨ أنشئ خطة يومي"}
        </button>
        {error && <p className="mt-3 rounded-xl bg-red-50 p-3 text-center text-sm text-red-700">{error}</p>}
      </div>

      {booting ? (
        <p className="mt-6 text-center text-slate-500">جارٍ التحميل…</p>
      ) : tasks.length === 0 ? (
        <p className="mt-6 text-center text-slate-500">لا توجد خطة لليوم بعد. اكتب ما تريد وسأرتبه لك.</p>
      ) : (
        <>
          <div className="mt-6 rounded-3xl bg-white p-4 shadow-sm">
            {summary && <p className="text-slate-700">{summary}</p>}
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full bg-green-500 transition-all" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-2 text-sm text-slate-500">أنجزت {done} من {tasks.length} · {pct}%</p>
          </div>

          <ul className="mt-4 space-y-3">
            {tasks.map((t) => {
              const pr = PRIORITY_LABEL[t.priority] ?? PRIORITY_LABEL.normal;
              const isDone = t.status === "done";
              return (
                <li key={t.id} className="rounded-2xl bg-white p-4 shadow-sm">
                  <div className="flex items-start gap-3">
                    <input type="checkbox" checked={isDone} onChange={() => toggle(t)}
                      className="mt-1 h-5 w-5 accent-green-600" aria-label="تم" />
                    <div className="flex-1">
                      <p className={`font-semibold ${isDone ? "text-slate-400 line-through" : ""}`}>{t.title}</p>
                      <p className="mt-1 text-sm text-slate-500">
                        {fmt(t.start_time)}{t.estimated_minutes ? ` · ${t.estimated_minutes} دقيقة` : ""}
                      </p>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${pr.cls}`}>{pr.text}</span>
                  </div>
                  {(t.ai_reason || t.task_steps.length > 0) && (
                    <button onClick={() => setOpen(open === t.id ? null : t.id)}
                      className="mt-2 text-sm text-brand-600">
                      {open === t.id ? "إخفاء التفاصيل" : "عرض الخطوات والسبب"}
                    </button>
                  )}
                  {open === t.id && (
                    <div className="mt-2 text-sm text-slate-600">
                      {t.ai_reason && <p className="mb-2">💡 {t.ai_reason}</p>}
                      <ol className="list-decimal space-y-1 pr-5">
                        {t.task_steps.map((s) => (
                          <li key={s.id}>{s.title}{s.estimated_minutes ? ` — ${s.estimated_minutes} د` : ""}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </>
      )}
    </main>
  );
}
