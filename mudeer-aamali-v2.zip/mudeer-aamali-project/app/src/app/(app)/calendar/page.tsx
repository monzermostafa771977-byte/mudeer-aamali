export default function CalendarPage() {
  return <main className="min-h-screen bg-slate-50 p-6"><h1 className="text-3xl font-bold text-brand-700">التقويم</h1></main>;
}
