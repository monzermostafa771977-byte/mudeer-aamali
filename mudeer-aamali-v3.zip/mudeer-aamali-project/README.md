# مدير أعمالي — My Business Manager (v3)

اكتب كل ما تريده صباحًا، فيحوّله الذكاء الاصطناعي إلى خطة يوم مرتبة بالأولويات والأوقات والخطوات، مع مراعاة مواعيد تقويمك.

## ما الجديد في v3
- **الإعدادات:** الاسم، ساعات العمل، مدة التركيز والاستراحة، تفعيل التنبيه الصوتي. يستخدمها الذكاء الاصطناعي عند التخطيط.
- **التنبيه الصوتي:** صوت + إشعار قبل موعد المهمة بخمس دقائق وعند موعدها (يعمل والتطبيق مفتوح في المتصفح).
- **تقويم Google:** ربط آمن (OAuth)، يتجنب الذكاء الاصطناعي مواعيدك، وزر «أضف للتقويم» لكل مهمة، وعرض أسبوعي.
- **المشاريع:** إنشاء مشاريع، وربط المهام بها تلقائيًا، وتقدم محسوب من المهام المنجزة.

## التشغيل
1. Supabase > SQL Editor: نفّذ بالترتيب `supabase/schema.sql` ثم `supabase/schema_v2.sql` (لا جديد في القاعدة في v3).
2. Supabase > Authentication > URL Configuration: Site URL = `http://localhost:3000`، وأضف `http://localhost:3000/auth/callback` ضمن Redirect URLs.
3. داخل مجلد `app` انسخ `.env.example` إلى `.env.local` واملأ القيم.
   مفتاح `SUPABASE_SERVICE_ROLE_KEY` تجده في Supabase > Project Settings > API (للخادم فقط، لا تشاركه).
4. شغّل:
```bash
npm install
npm run dev
```

## إعداد ربط Google Calendar (مرة واحدة)
1. افتح console.cloud.google.com وأنشئ مشروعًا.
2. APIs & Services > Library: فعّل **Google Calendar API**.
3. OAuth consent screen: النوع External، ثم أضف بريدك ضمن **Test users** (يكفي للتجربة، حتى 100 مستخدم).
4. Credentials > Create credentials > OAuth client ID > نوع Web application.
5. أضف في Authorized redirect URIs: `http://localhost:3000/api/google/callback`
   (وعند النشر: `https://رابط-موقعك/api/google/callback`).
6. انسخ Client ID وClient Secret إلى `.env.local`.
7. من التطبيق: الإعدادات > ربط تقويم Google.

> الصلاحية المطلوبة `calendar.events` (قراءة وكتابة المواعيد). ستظهر لك شاشة تحذير «التطبيق غير موثّق» أثناء التجربة؛ هذا طبيعي. للإطلاق العام يلزم تقديم التطبيق لمراجعة Google.

## النشر على Vercel
أضف نفس متغيرات البيئة (ومعها `APP_URL` برابط الموقع)، وأضف الرابط إلى Site URL وRedirect URLs في Supabase، وإلى redirect URIs في Google.

## حدود معروفة
- التنبيه الصوتي يعمل فقط والتطبيق مفتوح. للتنبيه والتطبيق مغلق نحتاج لاحقًا PWA + إشعارات Push + مهمة مجدولة على الخادم.
- إعادة إنشاء خطة اليوم تستبدل المهام داخل التطبيق، لكن مواعيد أُضيفت سابقًا إلى Google تبقى هناك ويراها الذكاء الاصطناعي كمواعيد.
- واجهة التطبيق عربية حاليًا؛ الإنجليزية مؤجلة.
