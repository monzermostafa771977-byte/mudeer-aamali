-- مدير أعمالي: مخطط قاعدة البيانات الأولي
-- نفّذ هذا الملف في Supabase SQL Editor

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  preferred_language text default 'ar',
  theme text default 'light',
  work_start_time time default '09:00',
  work_end_time time default '17:00',
  focus_duration_minutes int default 45,
  break_duration_minutes int default 10,
  voice_alerts_enabled boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;
create policy "Users can view own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update to authenticated using (auth.uid() = id);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  description text,
  color text default '#1B3A6B',
  due_date date,
  status text default 'active',
  progress int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.projects enable row level security;
create policy "Users can manage own projects" on public.projects for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.daily_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_date date not null,
  morning_input text,
  daily_goal text,
  ai_summary text,
  status text default 'draft',
  total_available_minutes int,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (user_id, plan_date)
);

alter table public.daily_plans enable row level security;
create policy "Users can manage own plans" on public.daily_plans for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id uuid references public.daily_plans(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  title text not null,
  description text,
  category text default 'work',
  priority text default 'normal',
  status text default 'todo',
  due_date date,
  start_time timestamptz,
  end_time timestamptz,
  estimated_minutes int,
  actual_minutes int,
  ai_reason text,
  is_recurring boolean default false,
  recurrence_rule text,
  calendar_event_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.tasks enable row level security;
create policy "Users can manage own tasks" on public.tasks for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index if not exists tasks_user_id_idx on public.tasks(user_id);
create index if not exists tasks_plan_id_idx on public.tasks(plan_id);

create table if not exists public.task_steps (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  order_index int default 0,
  estimated_minutes int,
  status text default 'todo',
  created_at timestamptz default now()
);

alter table public.task_steps enable row level security;
create policy "Users can manage own task steps" on public.task_steps for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid references public.tasks(id) on delete cascade,
  reminder_type text not null,
  remind_at timestamptz not null,
  message text not null,
  voice_text text,
  sound_enabled boolean default true,
  status text default 'scheduled',
  created_at timestamptz default now()
);

alter table public.reminders enable row level security;
create policy "Users can manage own reminders" on public.reminders for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index if not exists reminders_user_id_idx on public.reminders(user_id);
create index if not exists reminders_remind_at_idx on public.reminders(remind_at);

create table if not exists public.calendar_connections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text default 'google',
  google_email text,
  access_token text,
  refresh_token text,
  token_expires_at timestamptz,
  scope text,
  connected_at timestamptz default now(),
  disconnected_at timestamptz
);

alter table public.calendar_connections enable row level security;
create policy "Users can manage own calendar connections" on public.calendar_connections for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  google_event_id text,
  title text not null,
  start_time timestamptz not null,
  end_time timestamptz not null,
  all_day boolean default false,
  location text,
  description text,
  source text default 'google',
  created_at timestamptz default now()
);

alter table public.calendar_events enable row level security;
create policy "Users can manage own calendar events" on public.calendar_events for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index if not exists calendar_events_user_id_idx on public.calendar_events(user_id);
create index if not exists calendar_events_start_time_idx on public.calendar_events(start_time);

create table if not exists public.ai_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id uuid references public.daily_plans(id) on delete set null,
  request_type text not null,
  input_text text,
  response_json jsonb,
  model text,
  status text default 'success',
  error_message text,
  created_at timestamptz default now()
);

alter table public.ai_requests enable row level security;
create policy "Users can view own ai requests" on public.ai_requests for select to authenticated using (auth.uid() = user_id);
