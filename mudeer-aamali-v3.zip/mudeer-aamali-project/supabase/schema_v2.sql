-- مدير أعمالي: تحديث v2 (نفّذه بعد schema.sql، ويمكن تنفيذه أكثر من مرة)

-- 1) إنشاء ملف المستخدم تلقائيًا عند التسجيل
drop policy if exists "Users can insert own profile" on public.profiles;
create policy "Users can insert own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- للمستخدمين المسجلين قبل هذا التحديث
insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

-- 2) السماح بتسجيل طلبات الذكاء الاصطناعي الخاصة بالمستخدم نفسه
drop policy if exists "Users can insert own ai requests" on public.ai_requests;
create policy "Users can insert own ai requests" on public.ai_requests
  for insert to authenticated with check (auth.uid() = user_id);

-- 3) تحديث updated_at تلقائيًا
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

drop trigger if exists set_updated_at_profiles on public.profiles;
create trigger set_updated_at_profiles before update on public.profiles for each row execute function public.set_updated_at();
drop trigger if exists set_updated_at_projects on public.projects;
create trigger set_updated_at_projects before update on public.projects for each row execute function public.set_updated_at();
drop trigger if exists set_updated_at_plans on public.daily_plans;
create trigger set_updated_at_plans before update on public.daily_plans for each row execute function public.set_updated_at();
drop trigger if exists set_updated_at_tasks on public.tasks;
create trigger set_updated_at_tasks before update on public.tasks for each row execute function public.set_updated_at();

-- 4) حماية مفاتيح Google: لا يقرأها المتصفح أبدًا (ستُدار من الخادم لاحقًا)
drop policy if exists "Users can manage own calendar connections" on public.calendar_connections;
