import { createAdminClient } from "@/lib/supabase/admin";

export const GOOGLE_SCOPE = "https://www.googleapis.com/auth/calendar.events";

export function googleConfigured() {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

export function redirectUri(origin: string) {
  return `${process.env.APP_URL || origin}/api/google/callback`;
}

export type CalEvent = {
  id: string; title: string; start: string; end: string; allDay: boolean; location?: string;
};

async function getConnection(userId: string) {
  const admin = createAdminClient();
  const { data } = await admin.from("calendar_connections")
    .select("id, google_email, access_token, refresh_token, token_expires_at")
    .eq("user_id", userId).is("disconnected_at", null)
    .order("connected_at", { ascending: false }).limit(1).maybeSingle();
  return data;
}

export async function getGoogleStatus(userId: string) {
  try {
    const conn = await getConnection(userId);
    return { connected: Boolean(conn), email: conn?.google_email ?? null };
  } catch {
    return { connected: false, email: null };
  }
}

async function getAccessToken(userId: string): Promise<string | null> {
  const conn = await getConnection(userId);
  if (!conn) return null;
  const exp = conn.token_expires_at ? new Date(conn.token_expires_at).getTime() : 0;
  if (conn.access_token && exp - Date.now() > 60_000) return conn.access_token;
  if (!conn.refresh_token) return null;

  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID!, client_secret: process.env.GOOGLE_CLIENT_SECRET!,
      refresh_token: conn.refresh_token, grant_type: "refresh_token"
    })
  });
  const data: any = await res.json().catch(() => ({}));
  const admin = createAdminClient();
  if (!res.ok) {
    // المستخدم سحب الصلاحية من حساب Google
    if (data?.error === "invalid_grant") {
      await admin.from("calendar_connections").update({ disconnected_at: new Date().toISOString() }).eq("id", conn.id);
    }
    return null;
  }
  await admin.from("calendar_connections").update({
    access_token: data.access_token,
    token_expires_at: new Date(Date.now() + (data.expires_in ?? 3600) * 1000).toISOString()
  }).eq("id", conn.id);
  return data.access_token as string;
}

// يرجع null إذا لم يكن الحساب مربوطًا أو فشل الطلب
export async function listEvents(userId: string, timeMin: string, timeMax: string): Promise<CalEvent[] | null> {
  try {
    const token = await getAccessToken(userId);
    if (!token) return null;
    const params = new URLSearchParams({
      timeMin, timeMax, singleEvents: "true", orderBy: "startTime", maxResults: "100"
    });
    const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events?${params}`, {
      headers: { Authorization: `Bearer ${token}` }, cache: "no-store"
    });
    if (!res.ok) return null;
    const data: any = await res.json();
    return (data.items ?? [])
      .filter((e: any) => e.status !== "cancelled" && (e.start?.dateTime || e.start?.date))
      .map((e: any): CalEvent => ({
        id: e.id, title: e.summary || "(بدون عنوان)",
        start: e.start.dateTime ?? e.start.date, end: e.end?.dateTime ?? e.end?.date ?? e.start.dateTime ?? e.start.date,
        allDay: !e.start.dateTime, location: e.location
      }));
  } catch {
    return null;
  }
}

export async function insertEvent(
  userId: string, ev: { title: string; description?: string; startIso: string; endIso: string }
): Promise<string | null> {
  try {
    const token = await getAccessToken(userId);
    if (!token) return null;
    const res = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        summary: ev.title, description: ev.description,
        start: { dateTime: ev.startIso }, end: { dateTime: ev.endIso },
        reminders: { useDefault: true }
      })
    });
    if (!res.ok) return null;
    const data: any = await res.json();
    return data.id ?? null;
  } catch {
    return null;
  }
}

export async function revokeAndDelete(userId: string) {
  const admin = createAdminClient();
  const conn = await getConnection(userId);
  const token = conn?.refresh_token || conn?.access_token;
  if (token) {
    await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(token)}`, { method: "POST" }).catch(() => {});
  }
  await admin.from("calendar_connections").delete().eq("user_id", userId);
}
