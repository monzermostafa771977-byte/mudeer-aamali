"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

const items = [
  { href: "/today", label: "اليوم" },
  { href: "/calendar", label: "التقويم" },
  { href: "/projects", label: "المشاريع" },
  { href: "/settings", label: "الإعدادات" }
];

export default function AppNav() {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await createClient().auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <>
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur">
        <span className="font-bold text-brand-700">مدير أعمالي</span>
        <button onClick={logout} className="text-sm text-slate-500 hover:text-brand-700">تسجيل الخروج</button>
      </header>
      <nav className="fixed inset-x-0 bottom-0 z-10 flex border-t border-slate-200 bg-white">
        {items.map((it) => {
          const active = pathname.startsWith(it.href);
          return (
            <Link key={it.href} href={it.href}
              className={`flex-1 py-3 text-center text-sm font-semibold ${active ? "text-brand-600" : "text-slate-500"}`}>
              {it.label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
