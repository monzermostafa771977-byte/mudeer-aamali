"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { playAlert } from "@/lib/alerts";

type T = { id: string; title: string; start_time: string };

function localDate() {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export default function ReminderProvider() {
  const supabase = useRef(createClient()).current;
  const tasksRef = useRef<T[]>([]);
  const enabledRef = useRef(true);
  const [banner, setBanner] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const { data: prof } = await supabase.from("profiles").select("voice_alerts_enabled").maybeSingle();
    enabledRef.current = prof?.voice_alerts_enabled ?? true;
    const { data } = await supabase.from("tasks").select("id, title, start_time")
      .eq("due_date", localDate()).eq("status", "todo").not("start_time", "is", null);
    tasksRef.current = (data as T[] | null) ?? [];
  }, [supabase]);

  const check = useCallback(() => {
    if (!enabledRef.current) return;
    const now = Date.now();
    for (const t of tasksRef.current) {
      const start = new Date(t.start_time).getTime();
      const pre = `alerted:${t.id}:pre:${start}`;
      const at = `alerted:${t.id}:start:${start}`;
      try {
        // قبل الموعد بخمس دقائق
        if (now >= start - 5 * 60000 && now < start && !localStorage.getItem(pre)) {
          localStorage.setItem(pre, "1");
          const mins = Math.max(1, Math.ceil((start - now) / 60000));
          const msg = `بعد ${mins} دقائق: ${t.title}`;
          setBanner(msg); playAlert(msg);
        }
        // عند الموعد (مع سماح عشر دقائق إذا تأخر المتصفح)
        if (now >= start && now < start + 10 * 60000 && !localStorage.getItem(at)) {
          localStorage.setItem(at, "1"); localStorage.setItem(pre, "1");
          const msg = `حان وقت: ${t.title}`;
          setBanner(msg); playAlert(msg);
        }
      } catch {}
    }
  }, []);

  useEffect(() => {
    refresh();
    const r = setInterval(refresh, 60000);
    const c = setInterval(check, 15000);
    const onVisible = () => { if (document.visibilityState === "visible") { refresh().then(check); } };
    document.addEventListener("visibilitychange", onVisible);
    return () => { clearInterval(r); clearInterval(c); document.removeEventListener("visibilitychange", onVisible); };
  }, [refresh, check]);

  if (!banner) return null;
  return (
    <div className="fixed inset-x-4 top-16 z-20 mx-auto max-w-xl rounded-2xl bg-brand-700 p-4 text-white shadow-xl" role="alert">
      <p className="font-semibold">🔔 {banner}</p>
      <button onClick={() => setBanner(null)} className="mt-3 rounded-xl bg-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/30">حسنًا</button>
    </div>
  );
}
