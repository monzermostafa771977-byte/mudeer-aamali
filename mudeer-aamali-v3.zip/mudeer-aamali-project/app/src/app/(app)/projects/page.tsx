"use client";

import { useCallback, useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Project = {
  id: string; name: string; description: string | null; color: string | null;
  due_date: string | null; status: string; tasks: { id: string; status: string }[];
};

const COLORS = ["#1B3A6B", "#2563EB", "#0D9488", "#16A34A", "#EA580C", "#9333EA"];
const STATUS: Record<string, string> = { active: "نشط", completed: "مكتمل", archived: "مؤرشف" };

export default function ProjectsPage() {
  const supabase = createClient();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [color, setColor] = useState(COLORS[0]);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from("projects")
      .select("id, name, description, color, due_date, status, tasks(id, status)")
      .order("created_at", { ascending: false });
    if (error) setError("تعذّر تحميل المشاريع.");
    setProjects((data as Project[] | null) ?? []);
    setLoading(false);
  }, [supabase]);

  useEffect(() => { load(); }, [load]);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true); setError("");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setSaving(false); return; }
    const { error } = await supabase.from("projects").insert({
      user_id: user.id, name: name.trim().slice(0, 120), description: description.trim() || null,
      color, due_date: dueDate || null
    });
    setSaving(false);
    if (error) { setError("تعذّر إنشاء المشروع."); return; }
    setName(""); setDescription(""); setDueDate("");
    load();
  }

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("projects").update({ status }).eq("id", id);
    if (error) setError("تعذّر تغيير الحالة."); else load();
  }

  async function remove(p: Project) {
    if (!confirm(`حذف المشروع «${p.name}»؟ ستبقى مهامه لكن دون ربط بالمشروع.`)) return;
    const { error } = await supabase.from("projects").delete().eq("id", p.id);
    if (error) setError("تعذّر الحذف."); else load();
  }

  const input = "mt-1 w-full rounded-xl border border-slate-300 px-4 py-3";

  return (
    <main className="mx-auto max-w-3xl p-4">
      <h1 className="text-2xl font-bold text-brand-700">المشاريع</h1>
      <p className="mt-1 text-sm text-slate-500">عندما تكتب مهامك في «اليوم» يربطها الذكاء الاصطناعي بمشاريعك النشطة تلقائيًا، ويُحسب التقدم من مهامك المنجزة.</p>

      <form onSubmit={add} className="mt-4 space-y-3 rounded-3xl bg-white p-4 shadow-sm">
        <div>
          <label className="text-sm font-medium">اسم المشروع</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required maxLength={120} className={input} />
        </div>
        <div>
          <label className="text-sm font-medium">وصف (اختياري)</label>
          <input value={description} onChange={(e) => setDescription(e.target.value)} maxLength={300} className={input} />
        </div>
        <div>
          <label className="text-sm font-medium">الموعد النهائي (اختياري)</label>
          <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className={input} />
        </div>
        <div className="flex items-center gap-2">
          {COLORS.map((c) => (
            <button key={c} type="button" onClick={() => setColor(c)} aria-label="لون"
              className={`h-8 w-8 rounded-full ${color === c ? "ring-2 ring-offset-2 ring-slate-400" : ""}`} style={{ background: c }} />
          ))}
        </div>
        <button disabled={saving} className="w-full rounded-xl bg-brand-500 py-3 font-semibold text-white hover:bg-brand-600 disabled:opacity-60">
          {saving ? "جارٍ الإنشاء…" : "+ مشروع جديد"}
        </button>
      </form>

      {error && <p className="mt-3 rounded-xl bg-red-50 p-3 text-center text-sm text-red-700">{error}</p>}

      {loading ? (
        <p className="mt-6 text-center text-slate-500">جارٍ التحميل…</p>
      ) : projects.length === 0 ? (
        <p className="mt-6 text-center text-slate-500">لا توجد مشاريع بعد.</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {projects.map((p) => {
            const total = p.tasks.length;
            const done = p.tasks.filter((t) => t.status === "done").length;
            const pct = total ? Math.round((done / total) * 100) : 0;
            return (
              <li key={p.id} className="rounded-2xl bg-white p-4 shadow-sm" style={{ borderRight: `6px solid ${p.color ?? COLORS[0]}` }}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-bold">{p.name}</p>
                    {p.description && <p className="text-sm text-slate-500">{p.description}</p>}
                    {p.due_date && <p className="mt-1 text-xs text-slate-500">الموعد النهائي: {new Date(p.due_date).toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" })}</p>}
                  </div>
                  <select value={p.status} onChange={(e) => setStatus(p.id, e.target.value)}
                    className="rounded-lg border border-slate-300 px-2 py-1 text-sm" aria-label="الحالة">
                    {Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full bg-green-500" style={{ width: `${pct}%` }} />
                </div>
                <div className="mt-2 flex items-center justify-between text-sm text-slate-500">
                  <span>{total ? `${done} من ${total} مهام · ${pct}%` : "لا توجد مهام مرتبطة بعد"}</span>
                  <button onClick={() => remove(p)} className="text-red-600">حذف</button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </main>
  );
}
