import AppNav from "@/components/AppNav";
import ReminderProvider from "@/components/ReminderProvider";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen pb-20">
      <AppNav />
      <ReminderProvider />
      {children}
    </div>
  );
}
