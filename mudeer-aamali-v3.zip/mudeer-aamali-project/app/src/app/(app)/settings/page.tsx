"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { playAlert, requestNotifications } from "@/lib/alerts";

type Google = { configured: boolean; connected: boolean; email: string | null };

const GOOGLE_MESSAGES: Record<string, { text: string; ok: boolean }> = {
  connected: { text: "تم ربط تقويم Google بنجاح.", ok: true },
  denied: { text: "لم تتم الموافقة على الربط.", ok: false },
  failed: { text: "فشل الربط. حاول مرة أخرى.", ok: false },
  no_refresh: { text: "لم تصل صلاحية الاستمرار من Google. أزل التطبيق من حسابك في Google ثم أعد المحاولة.", ok: false },
  not_configured: { text: "ربط Google غير مفعّل على الخادم بعد (راجع README).", ok: false }
};

export default function SettingsPage() {
  const supabase = createClient();
  const [fullName, setFullName] = useState("");
  const [workStart, setWorkStart] = useState("09:00");
  const [workEnd, setWorkEnd] = useState("17:00");
  const [focus, setFocus] = useState(45);
  const [brk, setBrk] = useState(10);
  const [voice, setVoice] = useState(true);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const [google, setGoogle] = useState<Google | null>(null);
  const [notifState, setNotifState] = useState("");

  useEffect(() => {
    (async () => {
      const { data: p } = await supabase.from("profiles").select("*").maybeSingle();
      if (p) {
        setFullName(p.full_name ?? "");
        setWorkStart((p.work_start_time ?? "09:00").slice(0, 5));
        setWorkEnd((p.work_end_time ?? "17:00").slice(0, 5));
        setFocus(p.focus_duration_minutes ?? 45);
        setBrk(p.break_duration_minutes ?? 10);
        setVoice(p.voice_alerts_enabled ?? true);
      }
      setLoading(false);
    })();
    fetch("/api/google/status").then((r) => r.json()).then(setGoogle).catch(() => {});
    const code = new URLSearchParams(window.location.search).get("google");
    if (code && GOOGLE_MESSAGES[code]) setMsg(GOOGLE_MESSAGES[code]);
    if ("Notification" in window) setNotifState(Notification.permission);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (workStart >= workEnd) { setMsg({ text: "وقت بداية العمل يجب أن يسبق وقت نهايته.", ok: false }); return; }
    if (focus < 10 || focus > 180 || brk < 1 || brk > 60) {
      setMsg({ text: "مدة التركيز بين 10 و180 دقيقة، والاستراحة بين 1 و60.", ok: false }); return;
    }
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setSaving(false); return; }
    const { error } = await supabase.from("profiles").upsert({
      id: user.id, full_name: fullName.trim() || null, work_start_time: workStart, work_end_time: workEnd,
      focus_duration_minutes: focus, break_duration_minutes: brk, voice_alerts_enabled: voice
    });
    setSaving(false);
    setMsg(error ? { text: "تعذّر حفظ الإعدادات.", ok: false } : { text: "تم حفظ الإعدادات.", ok: true });
  }

  async function testAlert() {
    const state = await requestNotifications();
    setNotifState(state);
    playAlert("هذا اختبار للتنبيه الصوتي من مدير أعمالي");
  }

  async function disconnect() {
    if (!confirm("هل تريد فصل تقويم Google؟")) return;
    await fetch("/api/google/disconnect", { method: "POST" });
    setGoogle((g) => (g ? { ...g, connected: false, email: null } : g));
    setMsg({ text: "تم فصل التقويم.", ok: true });
  }

  const input = "mt-2 w-full rounded-xl border border-slate-300 px-4 py-3";
  if (loading) return <p className="p-6 text-center text-slate-500">جارٍ التحميل…</p>;

  return (
    <main className="mx-auto max-w-2xl space-y-4 p-4">
      <h1 className="text-2xl font-bold text-brand-700">الإعدادات</h1>
      {msg && <p className={`rounded-xl p-3 text-center text-sm ${msg.ok ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>{msg.text}</p>}

      <form onSubmit={save} className="space-y-4 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="font-bold">ملفك وأوقات عملك</h2>
        <p className="text-sm text-slate-500">يستخدمها الذكاء الاصطناعي عند ترتيب خطة يومك.</p>
        <div>
          <label className="text-sm font-medium">الاسم</label>
          <input value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={80} className={input} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium">بداية العمل</label>
            <input type="time" value={workStart} onChange={(e) => setWorkStart(e.target.value)} required className={input} />
          </div>
          <div>
            <label className="text-sm font-medium">نهاية العمل</label>
            <input type="time" value={workEnd} onChange={(e) => setWorkEnd(e.target.value)} required className={input} />
          </div>
          <div>
            <label className="text-sm font-medium">مدة التركيز (دقيقة)</label>
            <input type="number" value={focus} min={10} max={180} onChange={(e) => setFocus(Number(e.target.value))} className={input} />
          </div>
          <div>
            <label className="text-sm font-medium">مدة الاستراحة (دقيقة)</label>
            <input type="number" value={brk} min={1} max={60} onChange={(e) => setBrk(Number(e.target.value))} className={input} />
          </div>
        </div>
        <label className="flex items-center gap-3">
          <input type="checkbox" checked={voice} onChange={(e) => setVoice(e.target.checked)} className="h-5 w-5 accent-brand-500" />
          <span className="font-medium">تفعيل التنبيه الصوتي للمهام</span>
        </label>
        <button type="submit" disabled={saving} className="w-full rounded-xl bg-brand-500 py-3 font-semibold text-white hover:bg-brand-600 disabled:opacity-60">
          {saving ? "جارٍ الحفظ…" : "حفظ الإعدادات"}
        </button>
      </form>

      <section className="space-y-3 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="font-bold">التنبيه الصوتي</h2>
        <p className="text-sm text-slate-600">
          يعمل التنبيه (صوت + إشعار) قبل موعد المهمة بخمس دقائق وعند موعدها، <b>طالما التطبيق مفتوح في المتصفح</b>.
          اضغط الزر لتجربة الصوت ولتفعيل إشعارات المتصفح.
        </p>
        <button onClick={testAlert} className="w-full rounded-xl border border-brand-500 py-3 font-semibold text-brand-700 hover:bg-brand-50">🔊 جرّب التنبيه</button>
        {notifState === "denied" && <p className="text-sm text-orange-700">إشعارات المتصفح محظورة؛ سيعمل الصوت والشريط داخل التطبيق فقط.</p>}
      </section>

      <section className="space-y-3 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="font-bold">تقويم Google</h2>
        {!google ? (
          <p className="text-sm text-slate-500">جارٍ التحقق…</p>
        ) : google.connected ? (
          <>
            <p className="text-sm text-green-700">✅ مربوط{google.email ? ` (${google.email})` : ""}</p>
            <button onClick={disconnect} className="w-full rounded-xl border border-red-300 py-3 font-semibold text-red-700 hover:bg-red-50">فصل التقويم</button>
          </>
        ) : google.configured ? (
          <>
            <p className="text-sm text-slate-600">اربط تقويمك ليتجنب الذكاء الاصطناعي مواعيدك، ولتضيف مهامك إلى التقويم بضغطة.</p>
            <a href="/api/google/connect" className="block w-full rounded-xl bg-brand-500 py-3 text-center font-semibold text-white hover:bg-brand-600">ربط تقويم Google</a>
          </>
        ) : (
          <p className="text-sm text-slate-500">ربط Google غير مفعّل بعد على الخادم (خطوات الإعداد في README).</p>
        )}
      </section>
    </main>
  );
}
