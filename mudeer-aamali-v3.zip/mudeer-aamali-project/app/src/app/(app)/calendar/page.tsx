"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type CalEvent = { id: string; title: string; start: string; end: string; allDay: boolean; location?: string };
type Task = { id: string; title: string; status: string; due_date: string; start_time: string | null };
type Item = { key: string; time: string; sort: number; title: string; kind: "event" | "task"; done?: boolean; sub?: string };

const p2 = (n: number) => String(n).padStart(2, "0");
const dateKey = (d: Date) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
const timeLabel = (iso: string) => new Date(iso).toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" });

export default function CalendarPage() {
  const supabase = createClient();
  const [days, setDays] = useState<{ key: string; label: string; items: Item[] }[]>([]);
  const [connected, setConnected] = useState(false);
  const [failed, setFailed] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const end = new Date(start.getTime() + 7 * 86400000);
      const list: Date[] = Array.from({ length: 7 }, (_, i) => new Date(start.getFullYear(), start.getMonth(), start.getDate() + i));
      const map: Record<string, Item[]> = Object.fromEntries(list.map((d) => [dateKey(d), []]));

      const [{ data: tasks }, evRes] = await Promise.all([
        supabase.from("tasks").select("id, title, status, due_date, start_time")
          .gte("due_date", dateKey(list[0])).lte("due_date", dateKey(list[6])),
        fetch(`/api/calendar/events?from=${start.toISOString()}&to=${end.toISOString()}`)
          .then((r) => r.json()).catch(() => ({ connected: false, events: [] }))
      ]);

      ((tasks as Task[] | null) ?? []).forEach((t) => {
        const k = t.due_date;
        if (!map[k]) return;
        map[k].push({
          key: `t-${t.id}`, kind: "task", title: t.title, done: t.status === "done",
          time: t.start_time ? timeLabel(t.start_time) : "", sort: t.start_time ? new Date(t.start_time).getTime() : 0
        });
      });

      setConnected(Boolean(evRes.connected));
      setFailed(Boolean(evRes.failed));
      ((evRes.events as CalEvent[] | undefined) ?? []).forEach((e) => {
        const k = e.allDay ? e.start : dateKey(new Date(e.start));
        if (!map[k]) return;
        map[k].push({
          key: `e-${e.id}`, kind: "event", title: e.title, sub: e.location,
          time: e.allDay ? "طوال اليوم" : `${timeLabel(e.start)} – ${timeLabel(e.end)}`,
          sort: e.allDay ? -1 : new Date(e.start).getTime()
        });
      });

      setDays(list.map((d) => ({
        key: dateKey(d),
        label: d.toLocaleDateString("ar-EG", { weekday: "long", day: "numeric", month: "long" }),
        items: map[dateKey(d)].sort((a, b) => a.sort - b.sort)
      })));
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main className="mx-auto max-w-3xl p-4">
      <h1 className="text-2xl font-bold text-brand-700">التقويم — الأسبوع القادم</h1>
      {!loading && !connected && (
        <p className="mt-3 rounded-xl bg-blue-50 p-3 text-sm text-slate-700">
          تقويم Google غير مربوط، فتظهر هنا مهامك فقط. <Link href="/settings" className="font-semibold text-brand-600">اربطه من الإعدادات</Link>
        </p>
      )}
      {failed && <p className="mt-3 rounded-xl bg-orange-50 p-3 text-sm text-orange-700">تعذّر جلب مواعيد Google الآن.</p>}
      {loading ? (
        <p className="mt-6 text-center text-slate-500">جارٍ التحميل…</p>
      ) : (
        <div className="mt-4 space-y-3">
          {days.map((d) => (
            <section key={d.key} className="rounded-2xl bg-white p-4 shadow-sm">
              <h2 className="font-bold">{d.label}</h2>
              {d.items.length === 0 ? (
                <p className="mt-1 text-sm text-slate-400">لا شيء مجدول</p>
              ) : (
                <ul className="mt-2 space-y-2">
                  {d.items.map((it) => (
                    <li key={it.key} className={`rounded-xl border-r-4 px-3 py-2 text-sm ${it.kind === "event" ? "border-brand-500 bg-blue-50" : "border-green-500 bg-green-50"}`}>
                      <span className="text-slate-500">{it.time}</span>{it.time && " · "}
                      <span className={it.done ? "text-slate-400 line-through" : ""}>{it.title}</span>
                      {it.sub && <span className="block text-xs text-slate-500">📍 {it.sub}</span>}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
          <p className="text-center text-xs text-slate-400">الأزرق: مواعيد Google · الأخضر: مهامك</p>
        </div>
      )}
    </main>
  );
}
