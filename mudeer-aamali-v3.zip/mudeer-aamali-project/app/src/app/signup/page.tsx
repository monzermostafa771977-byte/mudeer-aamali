"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SignupPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setMessage("");
    const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/auth/callback` } });
    setLoading(false);
    if (error) { setMessage(error.message); return; }
    setMessage("تم إنشاء الحساب. تحقق من بريدك الإلكتروني لتأكيد الحساب.");
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <form onSubmit={handleSignup} className="w-full max-w-md rounded-3xl bg-white p-8 shadow-xl">
        <h1 className="text-2xl font-bold text-brand-700">إنشاء حساب</h1>
        <label className="mt-6 block text-sm font-medium">البريد الإلكتروني</label>
        <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3" />
        <label className="mt-4 block text-sm font-medium">كلمة المرور</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={8} className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3" />
        <button type="submit" disabled={loading} className="mt-6 w-full rounded-xl bg-brand-500 py-3 font-semibold text-white hover:bg-brand-600 disabled:opacity-60">{loading ? "جارٍ الإنشاء…" : "إنشاء الحساب"}</button>
        {message && <p className="mt-4 rounded-xl bg-slate-100 p-3 text-center text-sm">{message}</p>}
      </form>
    </main>
  );
}
