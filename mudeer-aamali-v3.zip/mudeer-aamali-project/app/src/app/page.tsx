import Link from "next/link";

export default function HomePage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-slate-50 to-blue-50 px-6">
      <div className="w-full max-w-xl rounded-3xl bg-white p-10 text-center shadow-xl">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-700 text-3xl font-bold text-white">م</div>
        <h1 className="text-4xl font-bold text-brand-700">مدير أعمالي</h1>
        <p className="mt-3 text-lg text-slate-600">نظّم أعمالك، أنشئ خطة يومك بذكاء، ولا تضيع مهمة مهمة.</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Link href="/login" className="flex-1 rounded-xl bg-brand-500 px-6 py-3 font-semibold text-white hover:bg-brand-600">تسجيل الدخول</Link>
          <Link href="/signup" className="flex-1 rounded-xl border border-brand-500 px-6 py-3 font-semibold text-brand-700 hover:bg-brand-50">إنشاء حساب</Link>
        </div>
      </div>
    </main>
  );
}
