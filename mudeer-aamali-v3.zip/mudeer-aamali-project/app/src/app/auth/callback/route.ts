import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// يستقبل رابط تأكيد البريد الإلكتروني من Supabase ويسجّل دخول المستخدم
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(`${origin}/today`);
  }
  return NextResponse.redirect(`${origin}/login`);
}
