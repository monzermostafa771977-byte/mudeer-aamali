import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";

const cairo = Cairo({ subsets: ["arabic", "latin"], display: "swap" });

export const metadata: Metadata = {
  title: "مدير أعمالي | My Business Manager",
  description: "نظّم أعمالك، أنشئ خطة يومك بذكاء، ولا تضيع مهمة مهمة."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${cairo.className} bg-slate-50 text-slate-900 antialiased`}>{children}</body>
    </html>
  );
}
