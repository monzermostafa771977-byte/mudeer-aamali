"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { setError("البريد الإلكتروني أو كلمة المرور غير صحيحة."); return; }
    router.push("/today"); router.refresh();
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <form onSubmit={handleLogin} className="w-full max-w-md rounded-3xl bg-white p-8 shadow-xl">
        <h1 className="text-2xl font-bold text-brand-700">تسجيل الدخول</h1>
        <label className="mt-6 block text-sm font-medium">البريد الإلكتروني</label>
        <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3" />
        <label className="mt-4 block text-sm font-medium">كلمة المرور</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={8} className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3" />
        <button type="submit" disabled={loading} className="mt-6 w-full rounded-xl bg-brand-500 py-3 font-semibold text-white hover:bg-brand-600 disabled:opacity-60">{loading ? "جارٍ الدخول…" : "دخول"}</button>
        {error && <p className="mt-4 rounded-xl bg-red-50 p-3 text-center text-sm text-red-700">{error}</p>}
      </form>
    </main>
  );
}
