import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { listEvents } from "@/lib/google";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_INPUT = 4000;
const DAILY_LIMIT = 20; // عدد طلبات الذكاء الاصطناعي لكل مستخدم خلال 24 ساعة

const PRIORITIES = ["urgent", "high", "normal", "low"] as const;
const CATEGORIES = ["work", "personal", "study", "health", "finance"] as const;

type Step = { title: string; minutes: number };
type PlanTask = {
  project_name: string;
  title: string; category: string; priority: string; estimated_minutes: number;
  start: string; reason: string; steps: Step[];
};

const planTool = {
  name: "submit_plan",
  description: "تسليم خطة اليوم المنظمة",
  input_schema: {
    type: "object",
    properties: {
      summary: { type: "string", description: "ملخص قصير وهادئ للخطة في جملتين" },
      tasks: {
        type: "array",
        items: {
          type: "object",
          properties: {
            title: { type: "string" },
            project_name: { type: "string", description: "اسم المشروع من قائمة مشاريع المستخدم إن كانت المهمة تنتمي لأحدها، وإلا اتركه فارغًا" },
            category: { type: "string", enum: [...CATEGORIES] },
            priority: { type: "string", enum: [...PRIORITIES] },
            estimated_minutes: { type: "integer" },
            start: { type: "string", description: "وقت البدء المقترح بصيغة HH:MM (24 ساعة)" },
            reason: { type: "string", description: "سبب الترتيب في جملة قصيرة" },
            steps: {
              type: "array",
              items: {
                type: "object",
                properties: { title: { type: "string" }, minutes: { type: "integer" } },
                required: ["title", "minutes"]
              }
            }
          },
          required: ["title", "category", "priority", "estimated_minutes", "start", "reason", "steps"]
        }
      }
    },
    required: ["summary", "tasks"]
  }
};

function clamp(n: unknown, min: number, max: number, fallback: number) {
  const v = typeof n === "number" && Number.isFinite(n) ? Math.round(n) : fallback;
  return Math.min(max, Math.max(min, v));
}

function cleanTasks(raw: unknown): PlanTask[] {
  if (!Array.isArray(raw)) return [];
  return raw.slice(0, 12).flatMap((t: any) => {
    if (!t || typeof t.title !== "string" || !t.title.trim()) return [];
    const start = typeof t.start === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(t.start) ? t.start : "09:00";
    const steps: Step[] = Array.isArray(t.steps)
      ? t.steps.slice(0, 8).flatMap((s: any) =>
          s && typeof s.title === "string" && s.title.trim()
            ? [{ title: s.title.trim().slice(0, 200), minutes: clamp(s.minutes, 1, 480, 10) }]
            : [])
      : [];
    return [{
      project_name: typeof t.project_name === "string" ? t.project_name.trim().slice(0, 120) : "",
      title: t.title.trim().slice(0, 200),
      category: (CATEGORIES as readonly string[]).includes(t.category) ? t.category : "work",
      priority: (PRIORITIES as readonly string[]).includes(t.priority) ? t.priority : "normal",
      estimated_minutes: clamp(t.estimated_minutes, 5, 480, 30),
      start,
      reason: typeof t.reason === "string" ? t.reason.slice(0, 300) : "",
      steps
    }];
  });
}

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "يجب تسجيل الدخول أولًا." }, { status: 401 });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "مفتاح الذكاء الاصطناعي غير مضبوط على الخادم." }, { status: 500 });

  let body: any;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "طلب غير صالح." }, { status: 400 }); }

  const text = typeof body.text === "string" ? body.text.trim() : "";
  const date = typeof body.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date) ? body.date : "";
  const nowTime = typeof body.nowTime === "string" && /^\d{2}:\d{2}$/.test(body.nowTime) ? body.nowTime : "09:00";
  const tzOffset = clamp(body.tzOffsetMinutes, -840, 840, 0);
  if (!text) return NextResponse.json({ error: "اكتب ما تريد إنجازه أولًا." }, { status: 400 });
  if (text.length > MAX_INPUT) return NextResponse.json({ error: "النص طويل جدًا." }, { status: 400 });
  if (!date) return NextResponse.json({ error: "التاريخ غير صالح." }, { status: 400 });

  // حد الاستخدام
  const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { count } = await supabase.from("ai_requests").select("id", { count: "exact", head: true }).gte("created_at", since);
  if ((count ?? 0) >= DAILY_LIMIT) {
    return NextResponse.json({ error: "وصلت إلى الحد اليومي لطلبات الذكاء الاصطناعي. حاول غدًا." }, { status: 429 });
  }

  const { data: profile } = await supabase.from("profiles")
    .select("work_start_time, work_end_time, focus_duration_minutes").eq("id", user.id).maybeSingle();
  const workStart = (profile?.work_start_time ?? "09:00").slice(0, 5);
  const workEnd = (profile?.work_end_time ?? "17:00").slice(0, 5);

  // مشاريع المستخدم النشطة (لربط المهام بها)
  const { data: projects } = await supabase.from("projects").select("id, name").eq("status", "active").limit(20);
  const projectList = projects ?? [];

  // مواعيد تقويم Google لهذا اليوم (إن كان مربوطًا)
  const [y, m, d] = date.split("-").map(Number);
  const dayStart = Date.UTC(y, m - 1, d, 0, 0) + tzOffset * 60000;
  const events = await listEvents(user.id, new Date(dayStart).toISOString(), new Date(dayStart + 86400000).toISOString());
  const pad = (n: number) => String(n).padStart(2, "0");
  const localHM = (iso: string) => {
    const t = new Date(new Date(iso).getTime() - tzOffset * 60000);
    return `${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}`;
  };
  const eventsText = events && events.length
    ? events.map((e) => (e.allDay ? `- طوال اليوم: ${e.title}` : `- ${localHM(e.start)} إلى ${localHM(e.end)}: ${e.title}`)).join("\n")
    : "لا توجد مواعيد في التقويم";

  const system = [
    "أنت مدير أعمال ذكي وهادئ. تحوّل كلام المستخدم الحر إلى خطة يوم واقعية قابلة للتنفيذ.",
    "القواعد: لا تتجاوز 5 مهام رئيسية في اليوم إلا للضرورة؛ لا تجدول قبل الوقت الحالي؛ ابقَ داخل ساعات العمل ما أمكن؛",
    "اترك فواصل راحة قصيرة؛ رتّب حسب الأهمية والاستعجال؛ قسّم المهام الكبيرة (أكثر من 30 دقيقة) إلى خطوات صغيرة؛",
    "لا تضع أي مهمة في وقت يتعارض مع مواعيد التقويم المذكورة؛ استغل الفراغات بينها.",
    "اكتب العناوين والأسباب بلغة المستخدم. لا تخترع التزامات لم يذكرها المستخدم.",
    "سلّم النتيجة دائمًا عبر الأداة submit_plan."
  ].join("\n");

  const userMsg = `التاريخ: ${date}\nالوقت الحالي: ${nowTime}\nساعات العمل: ${workStart} إلى ${workEnd}\nمدة التركيز المفضلة: ${profile?.focus_duration_minutes ?? 45} دقيقة\n\nمواعيد التقويم اليوم:\n${eventsText}\n\nمشاريع المستخدم: ${projectList.length ? projectList.map((p) => p.name).join("، ") : "لا توجد"}\n\nما يريده المستخدم اليوم:\n${text}`;

  const model = process.env.ANTHROPIC_MODEL || "claude-haiku-5-5";
  let summary = "";
  let tasks: PlanTask[] = [];
  let aiJson: unknown = null;
  let failure = "";

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model, max_tokens: 3000, system,
        messages: [{ role: "user", content: userMsg }],
        tools: [planTool],
        tool_choice: { type: "tool", name: "submit_plan" }
      })
    });
    const data: any = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || `AI error ${res.status}`);
    const block = Array.isArray(data.content) ? data.content.find((b: any) => b.type === "tool_use") : null;
    aiJson = block?.input ?? null;
    summary = typeof (aiJson as any)?.summary === "string" ? (aiJson as any).summary.slice(0, 500) : "";
    tasks = cleanTasks((aiJson as any)?.tasks);
    if (tasks.length === 0) throw new Error("لم يرجع الذكاء الاصطناعي مهام صالحة.");
  } catch (e: any) {
    failure = e?.message ?? "خطأ غير معروف";
  }

  await supabase.from("ai_requests").insert({
    user_id: user.id, request_type: "daily_plan", input_text: text,
    response_json: aiJson, model, status: failure ? "error" : "success", error_message: failure || null
  });
  if (failure) return NextResponse.json({ error: "تعذّر إنشاء الخطة الآن. حاول مرة أخرى." }, { status: 502 });

  // حفظ الخطة (إعادة الإنشاء تستبدل خطة نفس اليوم)
  const { data: plan, error: planErr } = await supabase.from("daily_plans").upsert(
    { user_id: user.id, plan_date: date, morning_input: text, ai_summary: summary, status: "active" },
    { onConflict: "user_id,plan_date" }
  ).select("id").single();
  if (planErr || !plan) return NextResponse.json({ error: "تعذّر حفظ الخطة." }, { status: 500 });

  await supabase.from("tasks").delete().eq("plan_id", plan.id);

  const toIso = (hhmm: string, addMin = 0) => {
    const [h, mi] = hhmm.split(":").map(Number);
    return new Date(Date.UTC(y, m - 1, d, h, mi) + (tzOffset + addMin) * 60000).toISOString();
  };

  const taskRows = tasks.map((t) => ({
    id: crypto.randomUUID(), user_id: user.id, plan_id: plan.id,
    project_id: projectList.find((p) => p.name === t.project_name)?.id ?? null, title: t.title, category: t.category,
    priority: t.priority, status: "todo", due_date: date, start_time: toIso(t.start),
    end_time: toIso(t.start, t.estimated_minutes), estimated_minutes: t.estimated_minutes, ai_reason: t.reason
  }));
  const { error: tErr } = await supabase.from("tasks").insert(taskRows);
  if (tErr) return NextResponse.json({ error: "تعذّر حفظ المهام." }, { status: 500 });

  const stepRows = tasks.flatMap((t, i) => t.steps.map((s, j) => ({
    task_id: taskRows[i].id, user_id: user.id, title: s.title, order_index: j, estimated_minutes: s.minutes
  })));
  if (stepRows.length) await supabase.from("task_steps").insert(stepRows);

  return NextResponse.json({ ok: true, summary });
}
