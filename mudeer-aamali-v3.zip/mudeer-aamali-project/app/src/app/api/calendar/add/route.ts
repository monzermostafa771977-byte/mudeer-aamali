import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getGoogleStatus, insertEvent } from "@/lib/google";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "يجب تسجيل الدخول." }, { status: 401 });

  const body: any = await request.json().catch(() => ({}));
  const taskId = typeof body.taskId === "string" ? body.taskId : "";
  if (!taskId) return NextResponse.json({ error: "مهمة غير صالحة." }, { status: 400 });

  const { data: task } = await supabase.from("tasks")
    .select("id, title, ai_reason, start_time, end_time, calendar_event_id").eq("id", taskId).maybeSingle();
  if (!task) return NextResponse.json({ error: "المهمة غير موجودة." }, { status: 404 });
  if (task.calendar_event_id) return NextResponse.json({ ok: true, already: true });
  if (!task.start_time || !task.end_time) return NextResponse.json({ error: "المهمة بلا وقت محدد." }, { status: 400 });

  const status = await getGoogleStatus(user.id);
  if (!status.connected) return NextResponse.json({ error: "اربط تقويم Google من الإعدادات أولًا." }, { status: 400 });

  const eventId = await insertEvent(user.id, {
    title: task.title, description: task.ai_reason ?? undefined,
    startIso: task.start_time, endIso: task.end_time
  });
  if (!eventId) return NextResponse.json({ error: "تعذّرت الإضافة إلى التقويم. حاول مرة أخرى." }, { status: 502 });

  await supabase.from("tasks").update({ calendar_event_id: eventId }).eq("id", task.id);
  return NextResponse.json({ ok: true });
}
