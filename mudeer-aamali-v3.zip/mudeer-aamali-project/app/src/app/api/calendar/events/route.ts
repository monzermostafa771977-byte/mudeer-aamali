import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getGoogleStatus, listEvents } from "@/lib/google";

export async function GET(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "يجب تسجيل الدخول." }, { status: 401 });

  const sp = new URL(request.url).searchParams;
  const from = new Date(sp.get("from") ?? "");
  const to = new Date(sp.get("to") ?? "");
  if (isNaN(+from) || isNaN(+to) || to <= from || +to - +from > 15 * 86400000) {
    return NextResponse.json({ error: "نطاق التاريخ غير صالح." }, { status: 400 });
  }

  const status = await getGoogleStatus(user.id);
  if (!status.connected) return NextResponse.json({ connected: false, events: [] });
  const events = await listEvents(user.id, from.toISOString(), to.toISOString());
  return NextResponse.json({ connected: true, events: events ?? [], failed: events === null });
}
