import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { revokeAndDelete } from "@/lib/google";

export async function POST() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "يجب تسجيل الدخول." }, { status: 401 });
  await revokeAndDelete(user.id);
  return NextResponse.json({ ok: true });
}
