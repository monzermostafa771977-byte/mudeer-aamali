import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { GOOGLE_SCOPE, redirectUri } from "@/lib/google";

export async function GET(request: NextRequest) {
  const origin = request.nextUrl.origin;
  const back = (code: string) => {
    const res = NextResponse.redirect(`${origin}/settings?google=${code}`);
    res.cookies.delete("g_state");
    return res;
  };

  const params = request.nextUrl.searchParams;
  if (params.get("error")) return back("denied");

  const code = params.get("code");
  const state = params.get("state");
  const saved = request.cookies.get("g_state")?.value;
  if (!code || !state || !saved || state !== saved) return back("failed");

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(`${origin}/login`);

  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code, client_id: process.env.GOOGLE_CLIENT_ID!, client_secret: process.env.GOOGLE_CLIENT_SECRET!,
      redirect_uri: redirectUri(origin), grant_type: "authorization_code"
    })
  });
  const tokens: any = await tokenRes.json().catch(() => ({}));
  if (!tokenRes.ok || !tokens.access_token) return back("failed");
  if (!tokens.refresh_token) return back("no_refresh");

  // بريد حساب Google هو معرّف التقويم الرئيسي
  let email: string | null = null;
  try {
    const cal = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary", {
      headers: { Authorization: `Bearer ${tokens.access_token}` }
    });
    if (cal.ok) email = ((await cal.json()) as any).id ?? null;
  } catch {}

  const admin = createAdminClient();
  await admin.from("calendar_connections").delete().eq("user_id", user.id);
  const { error } = await admin.from("calendar_connections").insert({
    user_id: user.id, provider: "google", google_email: email,
    access_token: tokens.access_token, refresh_token: tokens.refresh_token,
    token_expires_at: new Date(Date.now() + (tokens.expires_in ?? 3600) * 1000).toISOString(),
    scope: tokens.scope ?? GOOGLE_SCOPE
  });
  if (error) return back("failed");
  return back("connected");
}
