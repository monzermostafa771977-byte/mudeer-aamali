import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getGoogleStatus, googleConfigured } from "@/lib/google";

export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "يجب تسجيل الدخول." }, { status: 401 });
  const status = await getGoogleStatus(user.id);
  return NextResponse.json({ configured: googleConfigured(), ...status });
}
