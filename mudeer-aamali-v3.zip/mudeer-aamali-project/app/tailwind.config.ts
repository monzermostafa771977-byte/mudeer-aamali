import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#EFF6FF",
          500: "#2563EB",
          600: "#1D4ED8",
          700: "#1B3A6B",
          900: "#0F1B2E"
        }
      }
    }
  },
  plugins: []
};

export default config;
